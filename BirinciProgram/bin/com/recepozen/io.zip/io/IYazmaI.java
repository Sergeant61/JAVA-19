package com.recepozen.io;

public interface IYazmaI {

	public void dosyaAc(String dosyaYolu);

	public void veriYaz(Insan insan);

	public void dosyaKapt();

}
