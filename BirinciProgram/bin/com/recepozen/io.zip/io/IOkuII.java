package com.recepozen.io;

public interface IOkuII {

	public void dosyaAcOku(String okunacakDosyaYolu, String yazilacakDosyaYolu);

}
