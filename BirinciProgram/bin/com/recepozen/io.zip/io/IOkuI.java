package com.recepozen.io;

public interface IOkuI {

	public void dosyaAcOku(String okunacakDosyaYolu);

}
