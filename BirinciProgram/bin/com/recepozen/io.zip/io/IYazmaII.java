package com.recepozen.io;

public interface IYazmaII {

	public void dosyaAc(String dosyaYolu);

	public void veriYaz(String okunan);

	public void dosyaKapt();

}
